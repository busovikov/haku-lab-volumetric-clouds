# Haku Lab · Volumetric Clouds

Run `npm install`, then `npm run dev`. Open http://127.0.0.1:5179/examples/library.html.

API: packages/volumetric-clouds/README.md. Tests: `npm test`.
